## Feeling Awesome! Thanks for thinking about this.

You can contribute us by filing issues, bugs and PRs.

### Contributing:
- Open issue regarding proposed change.
- Repo owner will contact you there.
- If your proposed change is approved, Fork this repo and do changes.
- Open PR against latest `development` branch. Add nice description in PR.
- You're done!
